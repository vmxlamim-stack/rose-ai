package com.rose.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.rose.ai.ui.MainViewModel
import com.rose.ai.ui.components.ChatBubble
import com.rose.ai.ui.components.InputBar
import com.rose.ai.ui.components.RoseLogo
import com.rose.ai.ui.components.TypingIndicator
import com.rose.ai.ui.components.VoiceOrb
import com.rose.ai.ui.theme.RoseNeon
import com.rose.ai.voice.VoiceState

private val codeTemplates = listOf(
    "Python" to "Write Python code for: ",
    "HTML/CSS/JS" to "Create a complete HTML, CSS and JavaScript page for: ",
    "Kotlin" to "Write Kotlin code for: ",
    "Explain" to "Explain this code step by step:\n",
    "Debug" to "Find and fix the bugs in this code, and explain what was wrong:\n",
    "Format" to "Format and clean up this code (keep the behavior identical):\n"
)

private val suggestions = listOf(
    "Open camera",
    "Search YouTube for lo-fi music",
    "Explain recursion simply",
    "আমাকে একটা ছোট গল্প বলো"
)

@Composable
fun MainScreen(vm: MainViewModel, onOpenSettings: () -> Unit, onOpenHistory: () -> Unit) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val voiceState by vm.voice.state.collectAsState()
    val partial by vm.voice.partialText.collectAsState()
    val level by vm.voice.level.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val messages = vm.messages

    LaunchedEffect(Unit) {
        vm.events.collect { snackbar.showSnackbar(it) }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) vm.startListening() else vm.notify("Microphone permission is needed for voice input.")
    }

    fun toggleListening() {
        when {
            voiceState == VoiceState.LISTENING -> vm.stopListening()
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED -> vm.startListening()
            else -> permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val lastLength = messages.lastOrNull()?.text?.length ?: 0
    LaunchedEffect(messages.size, lastLength, vm.isLoading, vm.currentId) {
        val count = messages.size + if (vm.isLoading) 1 else 0
        if (count > 0) listState.scrollToItem(count - 1, Int.MAX_VALUE)
    }

    val orbSize by animateDpAsState(if (messages.isEmpty()) 210.dp else 96.dp, label = "orbSize")
    val status = when {
        voiceState == VoiceState.LISTENING -> "Listening…"
        voiceState == VoiceState.SPEAKING -> "Speaking…"
        vm.isLoading -> "Thinking…"
        vm.isStreaming -> "Replying…"
        else -> "Ready"
    }
    val statusColor = when {
        voiceState == VoiceState.LISTENING -> Color(0xFFFF4D6D)
        voiceState == VoiceState.SPEAKING -> Color(0xFFB388FF)
        vm.isStreaming -> Color(0xFFFFC66D)
        else -> Color(0xFF59E39A)
    }

    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            // Top bar
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onOpenHistory) {
                    Icon(Icons.Filled.History, "Chat history", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { vm.newChat() }) {
                    Icon(Icons.Filled.Add, "New chat", tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.weight(1f))
                RoseLogo()
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { vm.setVoiceEnabled(!settings.voiceEnabled) }) {
                    Icon(
                        if (settings.voiceEnabled) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                        if (settings.voiceEnabled) "Voice on" else "Voice off",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Settings, "Settings", tint = MaterialTheme.colorScheme.primary)
                }
            }

            // Voice orb + status
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                VoiceOrb(
                    state = voiceState,
                    level = level,
                    thinking = vm.isLoading,
                    size = orbSize,
                    onClick = { toggleListening() }
                )
                Row(
                    Modifier.padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    OutlinedButton(
                        onClick = { toggleListening() },
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            horizontal = 12.dp,
                            vertical = 0.dp
                        ),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(
                            if (voiceState == VoiceState.LISTENING) Icons.Filled.Stop else Icons.Filled.Mic,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (voiceState == VoiceState.LISTENING) "Stop listening" else "Start listening",
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Mode chips
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !vm.codingMode,
                    onClick = { vm.codingMode = false },
                    label = { Text("💬 Chat") }
                )
                FilterChip(
                    selected = vm.codingMode,
                    onClick = { vm.codingMode = true },
                    label = { Text("</> Code mode") }
                )
            }
            if (vm.codingMode) {
                LazyRow(
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(codeTemplates) { (label, template) ->
                        AssistChip(onClick = { input = template }, label = { Text(label) })
                    }
                }
            }

            // Conversation
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (messages.isEmpty()) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "Hi, I'm ROSE 🌹",
                            fontSize = 24.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            "Ask me anything in বাংলা, Banglish or English.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(suggestions) { s ->
                                AssistChip(onClick = { vm.send(s) }, label = { Text(s) })
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            horizontal = 12.dp,
                            vertical = 8.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(messages, key = { it.id }) { m ->
                            ChatBubble(m, onSpeak = { vm.speak(it) })
                        }
                        if (vm.isLoading) {
                            item { TypingIndicator() }
                        }
                    }
                }
            }

            if (voiceState == VoiceState.LISTENING && partial.isNotBlank()) {
                Text(
                    partial,
                    color = RoseNeon,
                    fontStyle = FontStyle.Italic,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                )
            }

            InputBar(
                value = input,
                onValueChange = { input = it },
                onSend = {
                    if (input.isNotBlank()) {
                        vm.send(input)
                        input = ""
                    }
                },
                onStop = { vm.stopGeneration() },
                onMic = { toggleListening() },
                listening = voiceState == VoiceState.LISTENING,
                busy = vm.isStreaming
            )
        }
    }
}
