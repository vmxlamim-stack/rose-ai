package com.rose.ai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rose.ai.ui.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(vm: MainViewModel, onBack: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val list = vm.conversations
        .filter { it.messages.isNotEmpty() }
        .sortedByDescending { it.updatedAt }
    val format = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = scheme.primary)
            }
            Text(
                "Chat history",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = scheme.onBackground,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = {
                vm.newChat()
                onBack()
            }) {
                Icon(Icons.Filled.Add, "New chat", tint = scheme.primary)
            }
        }

        if (list.isEmpty()) {
            Text(
                "No saved chats yet. Start a conversation with ROSE 🌹",
                color = scheme.onSurfaceVariant,
                modifier = Modifier.padding(24.dp)
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(list, key = { it.id }) { c ->
                    val selected = c.id == vm.currentId
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                vm.openConversation(c.id)
                                onBack()
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = scheme.surfaceVariant.copy(alpha = 0.7f)
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (selected) scheme.primary else scheme.primary.copy(alpha = 0.25f)
                        )
                    ) {
                        Row(
                            Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    c.title,
                                    color = scheme.onSurface,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    "${format.format(Date(c.updatedAt))} · ${c.messages.size} messages",
                                    color = scheme.onSurfaceVariant,
                                    fontSize = 12.sp
                                )
                            }
                            IconButton(onClick = { vm.deleteConversation(c.id) }) {
                                Icon(Icons.Filled.Delete, "Delete chat", tint = scheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}
