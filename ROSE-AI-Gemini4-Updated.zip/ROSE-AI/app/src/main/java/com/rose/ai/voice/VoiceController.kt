package com.rose.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.rose.ai.settings.AppLanguage
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceState { IDLE, LISTENING, SPEAKING }

data class VoiceOption(
    val name: String,
    val label: String,
    val languageTag: String,
    val likelyFemale: Boolean
)

/**
 * Wraps Android SpeechRecognizer (speech-to-text) and TextToSpeech.
 * Must be created and used from the main thread.
 */
class VoiceController(context: Context) {
    private val appContext = context.applicationContext

    private val _state = MutableStateFlow(VoiceState.IDLE)
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val _voices = MutableStateFlow<List<VoiceOption>>(emptyList())
    val voices: StateFlow<List<VoiceOption>> = _voices.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()

    /** Called on the main thread with the final recognized text. */
    var onFinalResult: ((String) -> Unit)? = null

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    @Volatile
    private var lastUtteranceId: String = ""

    private val utteranceListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            _state.value = VoiceState.SPEAKING
        }

        override fun onDone(utteranceId: String?) {
            if (utteranceId == lastUtteranceId) _state.value = VoiceState.IDLE
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            if (utteranceId == lastUtteranceId) _state.value = VoiceState.IDLE
        }
    }

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(utteranceListener)
                loadVoices()
            } else {
                ttsReady = false
            }
        }
    }

    // ---------------------------------------------------------------- TTS

    private fun loadVoices() {
        val all: List<Voice> = try {
            tts?.voices?.toList().orEmpty()
        } catch (e: Exception) {
            emptyList()
        }
        _voices.value = all
            .filter { it.locale.language == "en" || it.locale.language == "bn" }
            .filter { !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) }
            .map {
                VoiceOption(
                    name = it.name,
                    label = "${it.locale.displayName} · ${it.name}",
                    languageTag = it.locale.toLanguageTag(),
                    likelyFemale = looksFemale(it.name)
                )
            }
            .sortedWith(compareBy({ !it.likelyFemale }, { it.languageTag }, { it.name }))
    }

    /** Android has no official gender flag; this is a best-effort guess from the voice name. */
    private fun looksFemale(name: String): Boolean {
        val n = name.lowercase(Locale.ROOT)
        return n.contains("female") ||
            listOf("-x-sfg", "-x-iob", "-x-iog", "-x-tpf").any { n.contains(it) }
    }

    fun speak(text: String, language: AppLanguage, rate: Float, voiceName: String) {
        val engine = tts
        if (engine == null || !ttsReady) {
            _events.tryEmit("Text-to-speech isn't available on this device yet.")
            return
        }
        val clean = sanitizeForSpeech(text)
        if (clean.isBlank()) return

        recognizer?.cancel()
        val bengali = when (language) {
            AppLanguage.BENGALI -> true
            AppLanguage.ENGLISH -> false
            AppLanguage.AUTO -> BENGALI_CHARS.containsMatchIn(clean)
        }
        val locale = Locale.forLanguageTag(if (bengali) "bn-BD" else "en-US")
        val chosen = if (voiceName.isNotBlank()) {
            try {
                engine.voices?.firstOrNull { it.name == voiceName }
            } catch (e: Exception) {
                null
            }
        } else null

        if (chosen != null && chosen.locale.language == locale.language) {
            engine.setVoice(chosen)
        } else {
            val result = engine.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                _events.tryEmit(
                    if (bengali) "Bengali voice data isn't installed. Install it in your phone's text-to-speech settings."
                    else "English voice data isn't installed."
                )
                return
            }
        }
        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        engine.setPitch(1.05f)

        val chunks = chunk(clean, 3000)
        val stamp = System.nanoTime()
        chunks.forEachIndexed { i, part ->
            val id = "rose-$stamp-$i"
            if (i == chunks.lastIndex) lastUtteranceId = id
            engine.speak(
                part,
                if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                null,
                id
            )
        }
    }

    fun stopSpeaking() {
        tts?.stop()
        if (_state.value == VoiceState.SPEAKING) _state.value = VoiceState.IDLE
    }

    private fun chunk(text: String, max: Int): List<String> {
        if (text.length <= max) return listOf(text)
        val out = mutableListOf<String>()
        var rest = text
        while (rest.length > max) {
            var cut = rest.lastIndexOf(". ", max)
            if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
            if (cut <= 0) cut = max
            out.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring(cut + 1).trim()
        }
        if (rest.isNotEmpty()) out.add(rest)
        return out
    }

    private fun sanitizeForSpeech(text: String): String = text
        .replace(CODE_FENCE, " The code is shown on screen. ")
        .replace(LINK, "\$1")
        .replace(EMOJI, "")
        .replace(MARKDOWN_CHARS, "")
        .replace(Regex("\\s+"), " ")
        .trim()

    // ---------------------------------------------------------------- STT

    fun startListening(language: AppLanguage) {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            _events.tryEmit("Speech recognition isn't available on this device.")
            return
        }
        stopSpeaking()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(appContext)
        r.setRecognitionListener(recognitionListener)
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            when (language) {
                AppLanguage.ENGLISH -> putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                AppLanguage.BENGALI -> putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                AppLanguage.AUTO -> Unit
            }
        }
        _partialText.value = ""
        _state.value = VoiceState.LISTENING
        r.startListening(intent)
    }

    /** Stops recording; whatever was heard is still delivered to [onFinalResult]. */
    fun stopListening() {
        recognizer?.stopListening()
        if (_state.value == VoiceState.LISTENING) _state.value = VoiceState.IDLE
        _level.value = 0f
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) _partialText.value = text
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            _state.value = VoiceState.IDLE
            _level.value = 0f
            _partialText.value = ""
            if (text.isNotBlank()) onFinalResult?.invoke(text)
        }

        override fun onError(error: Int) {
            _state.value = VoiceState.IDLE
            _level.value = 0f
            _partialText.value = ""
            if (error != SpeechRecognizer.ERROR_CLIENT) {
                _events.tryEmit(errorMessage(error))
            }
        }
    }

    private fun errorMessage(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Please try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs an internet connection."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again."
        SpeechRecognizer.ERROR_AUDIO -> "There was a problem recording audio."
        else -> "Speech recognition error ($code)."
    }

    fun release() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }

    private companion object {
        val BENGALI_CHARS = Regex("[\\u0980-\\u09FF]")
        val CODE_FENCE = Regex("```[\\s\\S]*?(?:```|\$)")
        val LINK = Regex("\\[([^\\]]*)]\\([^)]*\\)")
        val EMOJI = Regex("[\\p{So}\\p{Cs}\\uFE0F]")
        val MARKDOWN_CHARS = Regex("[*_#`>~]+")
    }
}
