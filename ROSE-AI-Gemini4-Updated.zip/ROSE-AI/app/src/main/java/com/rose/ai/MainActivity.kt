package com.rose.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rose.ai.ui.MainViewModel
import com.rose.ai.ui.screens.HistoryScreen
import com.rose.ai.ui.screens.MainScreen
import com.rose.ai.ui.screens.SettingsScreen
import com.rose.ai.ui.theme.RoseTheme
import com.rose.ai.ui.theme.roseBackground

enum class Screen { MAIN, SETTINGS, HISTORY }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            val settings by vm.settings.collectAsState()
            val dark = settings.darkTheme

            DisposableEffect(dark) {
                val transparent = android.graphics.Color.TRANSPARENT
                val style = if (dark) {
                    SystemBarStyle.dark(transparent)
                } else {
                    SystemBarStyle.light(transparent, transparent)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }

            RoseTheme(dark = dark) {
                RoseApp(vm = vm, dark = dark)
            }
        }
    }
}

@Composable
fun RoseApp(vm: MainViewModel, dark: Boolean) {
    var screen by rememberSaveable { mutableStateOf(Screen.MAIN) }
    val context = LocalContext.current

    BackHandler(enabled = screen != Screen.MAIN) { screen = Screen.MAIN }

    Box(Modifier.fillMaxSize().background(roseBackground(dark))) {
        when (screen) {
            Screen.MAIN -> MainScreen(
                vm = vm,
                onOpenSettings = { screen = Screen.SETTINGS },
                onOpenHistory = { screen = Screen.HISTORY }
            )
            Screen.SETTINGS -> SettingsScreen(vm = vm, onBack = { screen = Screen.MAIN })
            Screen.HISTORY -> HistoryScreen(vm = vm, onBack = { screen = Screen.MAIN })
        }
    }

    // Phone actions always need an explicit "yes".
    vm.pendingAction?.let { action ->
        AlertDialog(
            onDismissRequest = { vm.dismissAction() },
            title = { Text("Confirm action") },
            text = { Text("${action.describe()}?") },
            confirmButton = { TextButton(onClick = { vm.confirmAction(context) }) { Text("Yes, do it") } },
            dismissButton = { TextButton(onClick = { vm.dismissAction() }) { Text("Cancel") } }
        )
    }

    // Memory is only saved after the user agrees.
    vm.pendingMemory?.let { fact ->
        AlertDialog(
            onDismissRequest = { vm.declineMemory() },
            title = { Text("Remember this?") },
            text = { Text("ROSE would like to remember:\n\n“$fact”\n\nIt stays on this phone and you can delete it anytime in Settings.") },
            confirmButton = { TextButton(onClick = { vm.acceptMemory() }) { Text("Remember") } },
            dismissButton = { TextButton(onClick = { vm.declineMemory() }) { Text("No thanks") } }
        )
    }
}
