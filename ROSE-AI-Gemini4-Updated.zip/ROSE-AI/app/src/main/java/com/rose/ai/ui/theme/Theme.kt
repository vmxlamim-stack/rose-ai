package com.rose.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val RoseNeon = Color(0xFFFF2D95)
val RosePinkSoft = Color(0xFFFF7AC6)
val NeonViolet = Color(0xFFB388FF)
val VoidBlack = Color(0xFF050309)
val DeepPurple = Color(0xFF1A0B2E)
val PurpleCard = Color(0xFF241238)

private val DarkColors = darkColorScheme(
    primary = RoseNeon,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF4A1238),
    onPrimaryContainer = Color(0xFFFFD6EA),
    secondary = NeonViolet,
    onSecondary = Color.Black,
    background = VoidBlack,
    onBackground = Color(0xFFF5E9FF),
    surface = DeepPurple,
    onSurface = Color(0xFFF5E9FF),
    surfaceVariant = PurpleCard,
    onSurfaceVariant = Color(0xFFCDB8E6),
    outline = Color(0xFF6B4A8F),
    error = Color(0xFFFF6B8A)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFFD6006F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFD6EA),
    onPrimaryContainer = Color(0xFF3B0A26),
    secondary = Color(0xFF7B3FD1),
    onSecondary = Color.White,
    background = Color(0xFFFFF4FA),
    onBackground = Color(0xFF2A1233),
    surface = Color.White,
    onSurface = Color(0xFF2A1233),
    surfaceVariant = Color(0xFFFBE4F1),
    onSurfaceVariant = Color(0xFF5E4468),
    outline = Color(0xFFB98BB0),
    error = Color(0xFFB3261E)
)

@Composable
fun RoseTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}

fun roseBackground(dark: Boolean): Brush =
    if (dark) {
        Brush.verticalGradient(listOf(Color(0xFF000000), Color(0xFF12061F), Color(0xFF2A0F45)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFFFF4FA), Color(0xFFFFE3F1)))
    }
