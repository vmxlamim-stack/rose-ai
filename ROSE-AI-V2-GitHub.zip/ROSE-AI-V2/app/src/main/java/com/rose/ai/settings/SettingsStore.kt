package com.rose.ai.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray

private val Context.roseDataStore: DataStore<Preferences> by preferencesDataStore(name = "rose_settings")

enum class AppLanguage(val label: String) {
    AUTO("Auto"),
    ENGLISH("English"),
    BENGALI("বাংলা")
}

data class AppSettings(
    val apiKey: String = "",
    val model: String = DEFAULT_MODEL,
    val language: AppLanguage = AppLanguage.AUTO,
    val voiceEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val voiceName: String = "",
    val darkTheme: Boolean = true,
    val memorySuggestions: Boolean = true,
    val memories: List<String> = emptyList()
) {
    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash"
        val SUGGESTED_MODELS = listOf(
            "gemini-3.8-flash",
            "gemini-3.7-flash",
            "gemini-3.6-flash",
            "gemini-3.5-flash",
            "gemini-3.5-flash-lite",
            "gemini-2.5-flash",
            "gemini-2.5-pro",
            "gemini-2.5-flash-lite"
        )
    }
}

class SettingsStore(private val context: Context) {

    private object Keys {
        val API_KEY = stringPreferencesKey("api_key")
        val MODEL = stringPreferencesKey("model")
        val LANGUAGE = stringPreferencesKey("language")
        val VOICE_ENABLED = booleanPreferencesKey("voice_enabled")
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
        val VOICE_NAME = stringPreferencesKey("voice_name")
        val DARK = booleanPreferencesKey("dark_theme")
        val MEMORY_SUGGEST = booleanPreferencesKey("memory_suggestions")
        val MEMORIES = stringPreferencesKey("memories")
    }

    val settings: Flow<AppSettings> = context.roseDataStore.data.map { p ->
        AppSettings(
            apiKey = p[Keys.API_KEY] ?: "",
            model = p[Keys.MODEL] ?: AppSettings.DEFAULT_MODEL,
            language = runCatching { AppLanguage.valueOf(p[Keys.LANGUAGE] ?: "AUTO") }
                .getOrDefault(AppLanguage.AUTO),
            voiceEnabled = p[Keys.VOICE_ENABLED] ?: true,
            speechRate = p[Keys.SPEECH_RATE] ?: 1.0f,
            voiceName = p[Keys.VOICE_NAME] ?: "",
            darkTheme = p[Keys.DARK] ?: true,
            memorySuggestions = p[Keys.MEMORY_SUGGEST] ?: true,
            memories = parseList(p[Keys.MEMORIES])
        )
    }

    suspend fun setApiKey(value: String) {
        context.roseDataStore.edit { it[Keys.API_KEY] = value.trim() }
    }

    suspend fun setModel(value: String) {
        context.roseDataStore.edit { it[Keys.MODEL] = value.trim() }
    }

    suspend fun setLanguage(value: AppLanguage) {
        context.roseDataStore.edit { it[Keys.LANGUAGE] = value.name }
    }

    suspend fun setVoiceEnabled(value: Boolean) {
        context.roseDataStore.edit { it[Keys.VOICE_ENABLED] = value }
    }

    suspend fun setSpeechRate(value: Float) {
        context.roseDataStore.edit { it[Keys.SPEECH_RATE] = value }
    }

    suspend fun setVoiceName(value: String) {
        context.roseDataStore.edit { it[Keys.VOICE_NAME] = value }
    }

    suspend fun setDarkTheme(value: Boolean) {
        context.roseDataStore.edit { it[Keys.DARK] = value }
    }

    suspend fun setMemorySuggestions(value: Boolean) {
        context.roseDataStore.edit { it[Keys.MEMORY_SUGGEST] = value }
    }

    suspend fun addMemory(text: String) {
        context.roseDataStore.edit { p ->
            val list = parseList(p[Keys.MEMORIES]).toMutableList()
            val clean = text.trim()
            if (clean.isNotEmpty() && clean !in list && list.size < 50) {
                list.add(clean)
                p[Keys.MEMORIES] = toJsonString(list)
            }
        }
    }

    suspend fun removeMemory(text: String) {
        context.roseDataStore.edit { p ->
            val list = parseList(p[Keys.MEMORIES]).filter { it != text }
            p[Keys.MEMORIES] = toJsonString(list)
        }
    }

    private fun parseList(json: String?): List<String> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun toJsonString(list: List<String>): String {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return arr.toString()
    }
}
