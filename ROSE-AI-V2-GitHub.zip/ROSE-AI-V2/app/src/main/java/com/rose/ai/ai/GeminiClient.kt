package com.rose.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(message: String, val httpCode: Int = 0) : Exception(message)

/**
 * Minimal client for the Gemini Developer API (generativelanguage.googleapis.com, v1beta).
 * Uses plain HTTPS + JSON so there are no extra SDK dependencies.
 * The API key is sent in the x-goog-api-key header (never in the URL, never hardcoded).
 */
object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"

    private fun normalizeModel(model: String): String =
        model.trim().removePrefix("models/").ifBlank { "gemini-3.8-flash" }

    private fun buildBody(model: String, systemPrompt: String, history: List<Pair<String, String>>): String {
        val contents = JSONArray()
        history.forEach { (role, text) ->
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val generationConfig = JSONObject()
        if (normalizeModel(model).startsWith("gemini-3")) {
            // Gemini 3.x uses thinkingLevel; leave sampling controls at model defaults.
            generationConfig.put(
                "thinkingConfig",
                JSONObject().put("thinkingLevel", "medium")
            )
        } else {
            // Preserve the existing behavior for Gemini 2.5 models.
            generationConfig.put("temperature", 0.8)
        }

        return JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
            .put("contents", contents)
            .put("generationConfig", generationConfig)
            .toString()
    }

    private fun open(apiKey: String, model: String, method: String, body: String): HttpURLConnection {
        val url = URL(BASE_URL + normalizeModel(model) + ":" + method)
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        conn.setRequestProperty("x-goog-api-key", apiKey.trim())
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        return conn
    }

    private fun checkResponse(conn: HttpURLConnection) {
        val code = conn.responseCode
        if (code in 200..299) return
        val err = try {
            conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
        } catch (e: Exception) {
            ""
        }
        conn.disconnect()
        throw GeminiException(describeError(code, err), code)
    }

    private fun describeError(code: Int, body: String): String {
        val apiMessage = runCatching {
            JSONObject(body).getJSONObject("error").getString("message")
        }.getOrNull()
        val hint = when (code) {
            400 -> "Request rejected. Check your API key and model name."
            401, 403 -> "Your API key was not accepted or lacks access to this model."
            404 -> "Model not found. Check the model name in Settings."
            429 -> "Rate limit or quota exceeded. Please wait a moment and retry."
            in 500..599 -> "The Gemini service is temporarily unavailable."
            else -> ""
        }
        val parts = listOf(hint, apiMessage.orEmpty()).filter { it.isNotBlank() }
        return if (parts.isEmpty()) "Gemini request failed (HTTP $code)." else parts.joinToString("\n")
    }

    private fun extractText(json: String): String {
        val root = JSONObject(json)
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            if (reason.isNotEmpty()) {
                throw GeminiException("The request was blocked by Gemini safety filters ($reason).")
            }
            return ""
        }
        val parts = candidates.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            if (part.optBoolean("thought", false)) continue
            sb.append(part.optString("text", ""))
        }
        return sb.toString()
    }

    /**
     * Streams the model's reply as text chunks (server-sent events).
     * [history] is a list of (role, text) where role is "user" or "model".
     */
    fun stream(
        apiKey: String,
        model: String,
        systemPrompt: String,
        history: List<Pair<String, String>>
    ): Flow<String> = flow {
        val conn = open(apiKey, model, "streamGenerateContent?alt=sse", buildBody(model, systemPrompt, history))
        try {
            checkResponse(conn)
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.removePrefix("data:").trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue
                    val text = extractText(payload)
                    if (text.isNotEmpty()) emit(text)
                }
            }
        } finally {
            conn.disconnect()
        }
    }.flowOn(Dispatchers.IO)

    /** Sends a tiny request to verify the API key + model name. */
    suspend fun testConnection(apiKey: String, model: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (apiKey.isBlank()) throw GeminiException("Please enter your Gemini API key first.")
                val body = buildBody(
                    model,
                    "You are a connectivity test. Reply with the single word OK.",
                    listOf("user" to "ping")
                )
                val conn = open(apiKey, model, "generateContent", body)
                try {
                    checkResponse(conn)
                    val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    extractText(text).trim().ifBlank { "OK" }
                } finally {
                    conn.disconnect()
                }
            }
        }
}
