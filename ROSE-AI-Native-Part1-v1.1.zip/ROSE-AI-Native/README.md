# ROSE AI — Native Android Foundation (Part 1)

This is a native Kotlin + Jetpack Compose Android project. It is not a WebView.

## Included in Part 1
- Editable assistant identity saved with Preferences DataStore.
- Settings screen and on-device Gemini API key entry.
- Microphone runtime permission request.
- Gemini Live WebSocket transport scaffold (Gemini 3.8 Live AUDIO session setup; audio streaming/playback not yet wired).
- Native YouTube app launch with browser fallback.
- Explicit user-enabled AccessibilityService foundation with tap/scroll primitives.
- Dark futuristic dashboard.

## Not yet implemented (do not treat as working)
- Continuous microphone PCM capture and streaming to Gemini Live.
- Gemini audio response decoding and speaker playback.
- Wake-word detection / always-on background listening.
- Natural-language-to-action planner and confirmation UI.
- Full app discovery/launch voice commands.
- Persistent chat history database (Room dependency is included for next part).
- Secure production credential broker / ephemeral token backend.

The Live API model and protocol are subject to Google's current documentation and account availability. The included transport is a connection scaffold, not a completed voice assistant. It requests Gemini 3.8 Live native AUDIO output, but microphone PCM streaming and received-audio playback are not yet wired; this is a connection scaffold, not a usable voice conversation.

## Versions
- Android Gradle Plugin: 8.11.1
- Gradle: 8.13
- Kotlin: 2.2.21
- JDK: 17
- compileSdk / targetSdk: 36
- minSdk: 26

Use Android SDK Platform 36 and Build Tools installed in your Android SDK.

## Build in Termux
1. Install Termux from a trusted source and update packages:
   ```sh
   pkg update && pkg upgrade
   pkg install openjdk-17 git unzip wget
   ```
2. Install Android command-line tools / SDK platform 36 and build-tools 36.0.0 using a compatible SDK setup. Termux's native Android build environment can be fragile; if Gradle cannot find SDK, set:
   ```sh
   export ANDROID_HOME=$HOME/android-sdk
   export ANDROID_SDK_ROOT=$ANDROID_HOME
   ```
3. Extract this project and enter its folder:
   ```sh
   unzip ROSE-AI-Native-Part1.zip
   cd ROSE-AI-Native
   ```
4. Generate the Gradle wrapper if the wrapper scripts/JAR are not present:
   ```sh
   gradle wrapper --gradle-version 8.13
   ```
5. Build:
   ```sh
   gradle assembleDebug
   ```
6. APK output:
   `app/build/outputs/apk/debug/app-debug.apk`

If the Android SDK is installed in a different location, create `local.properties`:
   `sdk.dir=/absolute/path/to/android-sdk`

## First launch
- Open Settings, enter an assistant name and your Gemini API key, then Save.
- Tap Connect and grant microphone permission if requested.
- Enable ROSE AI under Android Settings > Accessibility only if you intend to test accessibility actions.

## API key warning
This Part 1 stores the API key in app preferences for local testing. Do not distribute an APK containing a personal API key. A production app should use a trusted backend to mint short-lived Live API credentials, apply quotas, and avoid embedding long-lived secrets in the APK.

## Accessibility safety
Accessibility access is powerful. Android will display an explicit system opt-in. Do not enable it unless you understand the permissions. This starter does not automatically tap or scroll on its own.
