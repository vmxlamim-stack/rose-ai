package com.roseai.assistant.voice

import okhttp3.*
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * WebSocket transport foundation for Gemini Live.
 * The current Live API schema/model availability can change; keep model selection configurable.
 * This transport sends setup and text client-content messages. PCM microphone streaming and
 * audio playback are intentionally not claimed as complete in this Part 1 foundation.
 */
class GeminiLiveClient(
    private val onStatus: (String) -> Unit,
    private val onText: (String) -> Unit
) {
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private var socket: WebSocket? = null

    fun connect(apiKey: String): Boolean {
        disconnect()
        val request = Request.Builder()
            .url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey")
            .build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                onStatus("WebSocket connected. Sending Live setup…")
                val setup = JSONObject()
                    .put("setup", JSONObject()
                        .put("model", "models/gemini-3.8-live")
                        .put("generation_config", JSONObject()
                            .put("response_modalities", org.json.JSONArray().put("AUDIO"))
                        .put("speech_config", JSONObject()
                            .put("voice_config", JSONObject()
                                .put("prebuilt_voice_config", JSONObject().put("voice_name", "Kore"))))))
                webSocket.send(setup.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                onText("Gemini event: ${text.take(1200)}")
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                onStatus("Received ${bytes.size} binary bytes.")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onStatus("Gemini connection error: ${t.message ?: "unknown error"}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                onStatus("Connection closed: $reason")
            }
        })
        return true
    }

    fun sendText(text: String) {
        val payload = JSONObject().put("client_content", JSONObject()
            .put("turns", org.json.JSONArray().put(JSONObject()
                .put("role", "user")
                .put("parts", org.json.JSONArray().put(JSONObject().put("text", text)))))
            .put("turn_complete", true))
        socket?.send(payload.toString())
    }

    fun disconnect() {
        socket?.close(1000, "User disconnected")
        socket = null
    }
}
