package com.roseai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.roseai.assistant.data.AssistantPrefs
import com.roseai.assistant.voice.GeminiLiveClient
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = AssistantPrefs(applicationContext)
        setContent {
            RoseTheme {
                RoseApp(
                    prefs = prefs,
                    onOpenAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                )
            }
        }
    }
}

@Composable
private fun RoseTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Color(0xFF9B8CFF),
        secondary = Color(0xFF59D8E8),
        background = Color(0xFF080B16),
        surface = Color(0xFF11182A)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun RoseApp(prefs: AssistantPrefs, onOpenAccessibility: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val assistantName by prefs.name.collectAsState(initial = "")
    val apiKey by prefs.apiKey.collectAsState(initial = "")
    var nameInput by remember(assistantName) { mutableStateOf(assistantName) }
    var keyInput by remember(apiKey) { mutableStateOf(apiKey) }
    var showSettings by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready. Configure Gemini to begin.") }
    var connected by remember { mutableStateOf(false) }
    val liveClient = remember { GeminiLiveClient(
        onStatus = { status = it },
        onText = { status = it }
    ) }
    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        status = if (granted) "Microphone permission granted. Tap Connect again." else "Microphone permission denied."
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("ROSE AI", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                        Text("PERSONAL ASSISTANT", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                    }
                    IconButton(onClick = { showSettings = !showSettings }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            }
            item {
                Spacer(Modifier.height(22.dp))
                Box(
                    Modifier.size(190.dp).background(Color(0xFF151D38), RoundedCornerShape(100.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(145.dp).background(Color(0xFF24244B), RoundedCornerShape(100.dp)),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(62.dp))
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text(if (assistantName.isBlank()) "Create Your AI Assistant" else assistantName,
                    style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Voice-first Android assistant", color = Color.LightGray)
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("STATUS", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.labelLarge)
                        Text(status)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                                } else if (keyInput.isBlank()) {
                                    showSettings = true
                                    status = "Add your Gemini API key in Settings first."
                                } else {
                                    scope.launch {
                                        prefs.saveApiKey(keyInput)
                                        connected = liveClient.connect(keyInput)
                                    }
                                }
                            }, modifier = Modifier.weight(1f)) { Text("Connect") }
                            OutlinedButton(onClick = {
                                liveClient.disconnect()
                                connected = false
                                status = "Disconnected"
                            }, modifier = Modifier.weight(1f)) { Text("Disconnect") }
                        }
                    }
                }
            }
            if (showSettings) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("ASSISTANT SETTINGS", color = MaterialTheme.colorScheme.secondary)
                            OutlinedTextField(value = nameInput, onValueChange = { nameInput = it },
                                label = { Text("Assistant name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = keyInput, onValueChange = { keyInput = it },
                                label = { Text("Gemini API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                scope.launch {
                                    prefs.saveName(nameInput.trim().ifBlank { "ROSE" })
                                    prefs.saveApiKey(keyInput.trim())
                                    status = "Settings saved."
                                    showSettings = false
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Save settings") }
                            OutlinedButton(onClick = onOpenAccessibility, modifier = Modifier.fillMaxWidth()) {
                                Text("Open Accessibility settings")
                            }
                            Text("For personal testing only: a key stored on-device can be extracted from a compromised device. For public release, use a trusted backend that issues short-lived credentials.",
                                style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                        }
                    }
                }
            }
            item {
                Text("PHONE ACTIONS", color = MaterialTheme.colorScheme.secondary,
                    style = MaterialTheme.typography.labelLarge, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val intent = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                        if (intent != null) context.startActivity(intent) else {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
                        }
                    }, modifier = Modifier.weight(1f)) { Text("Open YouTube") }
                    OutlinedButton(onClick = onOpenAccessibility, modifier = Modifier.weight(1f)) { Text("Touch access") }
                }
            }
            item {
                Text("Part 1 foundation: identity, settings, microphone permission, Gemini Live WebSocket connection scaffold, app launch and explicit AccessibilityService opt-in.",
                    color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
