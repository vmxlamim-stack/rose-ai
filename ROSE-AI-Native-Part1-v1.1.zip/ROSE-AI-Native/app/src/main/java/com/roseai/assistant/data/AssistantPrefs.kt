package com.roseai.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "rose_settings")

class AssistantPrefs(private val context: Context) {
    private val NAME = stringPreferencesKey("assistant_name")
    private val API_KEY = stringPreferencesKey("gemini_api_key")

    val name = context.dataStore.data.map { it[NAME] ?: "" }
    val apiKey = context.dataStore.data.map { it[API_KEY] ?: "" }

    suspend fun saveName(value: String) {
        context.dataStore.edit { it[NAME] = value }
    }

    suspend fun saveApiKey(value: String) {
        context.dataStore.edit { it[API_KEY] = value }
    }
}
